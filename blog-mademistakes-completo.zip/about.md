---
layout: default
title: Acerca de
permalink: /about/
---

<div class="about-content">
  <h1>Hola, soy [Tu Nombre]</h1>

  <p>
    Soy un escritor en desarrollo que está aprendiendo a escribir en público. 
    También trabajo en marketing digital, creo landing pages y desarrollo con PHP, MySQL y Bootstrap.
  </p>

  <h2>Por qué este blog</h2>

  <p>
    Durante mucho tiempo luché con la procrastinación, la hoja en blanco y la falta de un sistema claro para escribir. 
    Este blog es mi compromiso público de documentar mi proceso, compartir lo que aprendo y, lo más importante, 
    <strong>escribir de forma consistente</strong>.
  </p>

  <h2>Qué encontrarás aquí</h2>

  <p>
    Este espacio es mi laboratorio de escritura. Aquí documento:
  </p>

  <ul>
    <li>Mi proceso de aprendizaje como escritor</li>
    <li>Ideas sobre marketing digital y desarrollo web</li>
    <li>Experimentos con diferentes formatos de contenido</li>
    <li>Reflexiones sobre productividad y sistemas de trabajo</li>
    <li>Todo lo que aprendo cada día</li>
  </ul>

  <h2>Mi filosofía</h2>

  <p>
    Creo en aprender en público, documentar hasta el más mínimo detalle y que el progreso 
    imperfecto es mejor que la perfección paralizante. Si estás leyendo esto, probablemente 
    estás en un viaje similar.
  </p>

  <h2>Conectemos</h2>

  <p>
    Me encantaría saber de ti. Puedes encontrarme en:
  </p>

  <ul>
    <li>Twitter: <a href="https://twitter.com/tuusuario" target="_blank">@tuusuario</a></li>
    <li>GitHub: <a href="https://github.com/tuusuario" target="_blank">github.com/tuusuario</a></li>
    <li>Email: <a href="mailto:tu@email.com">tu@email.com</a></li>
  </ul>

  <p>
    <em>Última actualización: {{ 'now' | date: "%B %Y" }}</em>
  </p>
</div>
